# Local Assets preview repro files

Drop the whole folder into a scene's `assets/` folder (keep the folder structure: the models
reference `../shared-textures/`), then open the scene in Creator Hub and go to Local Assets.

| File | What it is | Before this fix | After this fix |
| --- | --- | --- | --- |
| `models/rock-parent-texture.glb` | Texture referenced as `../shared-textures/FanstasyPack_TX.png`, the layout the Optimize tool writes | No thumbnail ever, each attempt costs 30 s in the background | Thumbnail within a few seconds; preview pane renders it textured |
| `models/nested/vase-two-levels-up.glb` | Same, two folders up (`../../shared-textures/…`) | Same as above | Same as above |
| `models/rock-missing-texture.glb` | Points at `../shared-textures/missing.png`, which does not exist | No thumbnail, 30 s each attempt | Tile shows the generic 3D icon right away; preview pane says "Preview unavailable" |
| `models/rock-sibling-texture.glb` + `models/FanstasyPack_TX.png` | Control: texture beside the model | Works | Works |
| `models/corrupt.glb` | Random bytes with a `.glb` name | No thumbnail, 30 s each attempt | Tile shows the 3D icon right away; preview pane says "Preview unavailable" |
| `audio/corrupt.mp3`, `audio/corrupt.ogg`, `audio/corrupt.wav` | Random bytes | Dead player | "Preview unavailable · The browser cannot play this file" |
| `audio/adpcm-codec.wav` | A real WAV in a codec Chromium does not decode (MS ADPCM) | Dead player | Same message |
| `video/corrupt.mp4` | Random bytes | Dead player | Same message |
| `video/mpeg2-codec.mp4` | A real MP4 in a codec Chromium does not decode (MPEG-2) | Dead player | Same message |
| `images/corrupt.png`, `images/corrupt.jpg` | Undecodable images | Broken-image icon | "Preview unavailable · The browser could not decode this image" |
| `images/truncated.jpg` | A JPEG cut off after 600 bytes | Partial image | Chromium decodes what it can, so this one may render partially; it must never break the pane |

In every case the inspector must stay up: the tree, viewport and the rest of the Local Assets tab keep
working, and selecting another file replaces the message.
